package frpmgr

//go:generate go run iconize.go -d icon
//go:generate go run resource.go
