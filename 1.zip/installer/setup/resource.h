#ifndef _RESOURCE_H
#define _RESOURCE_H

#define IDI_ICON        10
#define IDR_MSI         11
#define IDD_LANG_DIALOG 100
#define IDC_LANG_COMBO  1000
#define IDC_STATIC      -1

#endif
