#ifndef _RESOURCE_H
#define _RESOURCE_H

#define IDI_APP       7
#define IDI_DOT       21

#define IDD_VALIDATE  VALDLG

#define IDC_TITLE     2000
#define IDC_STATIC1   2001
#define IDC_STATIC2   2002
#define IDC_EDIT      2003
#define IDC_ICON      2004

#endif
